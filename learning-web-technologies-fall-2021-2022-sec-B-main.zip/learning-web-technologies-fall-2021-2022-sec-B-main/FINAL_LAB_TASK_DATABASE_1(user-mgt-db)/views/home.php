<?php 

	include('header.php');

?>

<html>
<head>
	<title>Home page</title>
</head>
<body>
	<center>
	<h1>Welcome home!</h1>
	<a href="create.php">Create New</a> |
	<a href="userlist.php">User List</a> |
	<a href="../controller/logout.php">Logout</a>
	</center>
</body>
</html>
