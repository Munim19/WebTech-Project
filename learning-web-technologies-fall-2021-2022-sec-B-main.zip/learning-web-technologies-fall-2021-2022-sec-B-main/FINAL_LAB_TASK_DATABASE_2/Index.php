<?php

	header('location: views/AddProduct.php');
?>