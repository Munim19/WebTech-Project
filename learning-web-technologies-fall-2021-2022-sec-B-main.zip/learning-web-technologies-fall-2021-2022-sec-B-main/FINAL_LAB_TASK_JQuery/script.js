
	
$('#submit').click(function(){
	alert($('#name').val());
	$('#name').val('');
});

$('#submit').click(function(){
	alert($('#email').val());
	$('#email').val('');
});

$('#submit').click(function(){
	alert($('#gender').val());
	$('#gender').val('');
});

$('#submit').click(function(){
	alert($('#dob').val());
	$('#dob').val('');
});

$('#submit').click(function(){
	alert($('#degree').val());
	$('#degree').val('');
});

$('#submit').click(function(){
	alert($('#picture').val());
	$('#picture').val('');
});