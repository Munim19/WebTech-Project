<?php
   session_start();

?>
<?php include('header.php');?>

<!DOCTYPE html>
<html>
<head>
	<title>HOMEPAGE</title>
</head>
<body>
	<center>
	<h1>WELLCOME TO THE HOMEPAGE</h1><br>
	<img src="../assets/aiub.jpg" width="100%">
	</center>
</body>
</html>
