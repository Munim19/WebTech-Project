<?php
   session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Log in Message</title>
</head>
<body>
	<center>
	<h1>Congratulations, You Are Successfully Logged In!!!</h1><br>
	<a href="home.php">HOME</a> |
	<a href="logout.php">Logout</a>
	</center>
</body>
</html>