<?php
		include('headerL.php');
?>
<!DOCTYPE html>
<html>
<head>
	<style>
.myButton {
	box-shadow:inset 0px 0px 0px 0px #dcecfb;
	background:linear-gradient(to bottom, #bddbfa 5%, #80b5ea 100%);
	background-color:#bddbfa;
	border-radius:8px;
	border:3px solid #3488db;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	color: black;
	font-size:20px;
	font-weight:bold;
	padding:13px 30px;
	text-decoration:none;
	text-shadow:0px 1px 0px #528ecc;
}
.myButton:hover,.myButton:active,.myButton:focus {
	background: #43A047;
}
	</style>
	<title>ABOUT US</title>


</head>
<body>
	<br>
	<center>
		<table align="center" width="100%" cellspacing="10" cellpadding="5">
			<tr>
				<td>
		<table border="3" width="100%">
			<tr align="center">
				<td>
					<img src="../assets/pic2.jpg" width="160px" height="195px">
				</td>
				<td>
		<table border="2" cellspacing="3" cellpadding="3" align="center">
			<tr align="center">
				<td colspan="2"><h2>Jihad Shahariar Joy</h2></td>
			</tr>
			<tr align="center">
				<td>ID : </td>
				<td> 19-40068-1</td>
			</tr>
			<tr align="center">
				<td>Email : </td>
				<td> jihadshahariarjoy2211@gmail.com </td>
			</tr>
			<tr align="center">
				<td width="28%">Program : </td>
				<td>Bachelor of Science in Computer Science & Engineering</td>
			</tr>
			<tr align="center">
				<td>Department : </td>
				<td align="center"> FACULTY OF SCIENCE & TECHNOLOGY </td>
			</tr>
		</table>
		</td>
		</tr>
		</table>
				</td>
				<td>
		<table border="3" width="100%">
			<tr align="center">
				<td>
					<img src="../assets/face2.jpg" width="150px" height="195px">
				</td>
				<td>
		<table border="2" cellspacing="3" cellpadding="3" align="center">
			<tr align="center">
				<td colspan="2"><h2>Bishal Paul</h2></td>
			</tr>
			<tr align="center">
				<td>ID : </td>
				<td> 17-35836-3</td>
			</tr>
			<tr align="center">
				<td>Email : </td>
				<td> bp.bishal404@gmail.com </td>
			</tr>
			<tr align="center">
				<td width="25%">Program : </td>
				<td>Bachelor of Science in Computer Science & Engineering</td>
			</tr>
			<tr align="center">
				<td>Department : </td>
				<td align="center"> FACULTY OF SCIENCE & TECHNOLOGY </td>
			</tr>
		</table>
		</td>
		</tr>
		</table>
				</td>
			</tr>
			<tr>
				<td>
		<table border="3" width="100%">
			<tr align="center">
				<td>
					<img src="../assets/face3.jpg" width="180px" height="195px">
				</td>
				<td>
		<table border="2" cellspacing="3" cellpadding="3" align="center">
			<tr align="center">
				<td colspan="2"><h2>Arumoy Das Gupta</h2></td>
			</tr>
			<tr align="center">
				<td>ID : </td>
				<td> 17-35765-3</td>
			</tr>
			<tr align="center">
				<td>Email : </td>
				<td> arumoydasgupta98@gmail.com </td>
			</tr>
			<tr align="center">
				<td width="25%">Program : </td>
				<td> Bachelor of Science in Computer Science & Engineering </td>
			</tr>
			<tr align="center">
				<td>Department : </td>
				<td align="center"> FACULTY OF SCIENCE & TECHNOLOGY </td>
			</tr>
		</table>
		</td>
		</tr>
		</table>
				</td>
				<td>
		<table border="3" width="100%">
			<tr align="center">
				<td>
					<img src="../assets/face4.jpg" width="160px" height="185px">
				</td>
				<td>
		<table border="2" cellspacing="3" cellpadding="3" align="center">
			<tr align="center">
				<td colspan="2"><h2>Amrin Ara</h2></td>
			</tr>
			<tr align="center">
				<td>ID : </td>
				<td> 18-36206-1</td>
			</tr>
			<tr align="center">
				<td>Email : </td>
				<td> amrinusra12@gmail.com </td>
			</tr>
			<tr align="center">
				<td width="25%">Program : </td>
				<td> Bachelor of Science in Computer Science & Engineering </td>
			</tr>
			<tr align="center">
				<td>Department : </td>
				<td align="center"> FACULTY OF SCIENCE & TECHNOLOGY </td>
			</tr>
		</table>
		</td>
		</tr>
		</table>
				</td>
			</tr>
		</table>
		</center>
		<br>
		<!-- <a href="home.php"><input type="button" name="" value="BACK / HOME"></a> -->
		<center>
		<div>
			<a href="login.php" class="myButton">LOGIN</a>
		</div>
	</center>
</body>
</html>
