<?php
		include('headerL.php');
?>
<!DOCTYPE html>
<html>
<head>
	<style>
		/*<a href="#" class="myButton">green</a>*/
.myButton {
	/*background-color:#2063b0;*/
	background-color:#2778d6;
	border-radius:30px;
	border:3px solid #08298a;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:18px;
	padding:15px 35px;
	text-decoration:none;
	text-shadow:0px 1px 0px #283966;
}
.myButton:hover,.myButton:active,.myButton:focus {
	background: #43A047;
}

.image {
	border-radius: 150px;
}

	</style>
	<title>CONTACT US</title>


</head>
<body>
	<!-- <center>
	
	<a href="https://www.facebook.com/jihadshahariar.joy/">
		<img src="../assets/Facebook_f_logo.png" width="300px" height="300px">
	</a>
		
	</center> -->

	<br>
	<center>
		<table>
			<tr>
				<td>
					<a href="https://www.facebook.com/Vishal.paul404/">
					<img src="../assets/face2.jpg" width="280px" height="300px" class="image">
					</a>
				</td>
				<td>
					<a href="https://www.facebook.com/jihadshahariar.joy/">
					<img src="../assets/pic2.jpg" width="280px" height="300px" class="image">
					</a>
				</td>
				<td>
					<a href="https://www.facebook.com/adg.arumoy/">
					<img src="../assets/face3.jpg" width="300px" height="300px" class="image">
					</a>
				</td>
				<td>
					<a href="https://www.facebook.com/amrin.khandaker.1/">
					<img src="../assets/face4.jpg" width="300px" height="300px" class="image">
					</a>
				</td>
			</tr>

			<tr align="center">
				<td>
					<a href="https://github.com/vishal606">
					<img src="../assets/github.png" width="200px" height="200px" class="image">
					</a>
				</td>
				<td>
					<a href="https://github.com/Jihad-Shahariar-Joy-19-40068-1">
					<img src="../assets/github.png" width="200px" height="200px" class="image">
					</a>
				</td>
				<td>
					<a href="https://github.com/Arumoy404">
					<img src="../assets/github.png" width="200px" height="200px" class="image">
					</a>
				</td>
				<td>
					<a href="https://github.com/AmrinAra18-36206-1">
					<img src="../assets/github.png" width="200px" height="200px" class="image">
					</a>
				</td>
			</tr>
		</table>

		<br>
		<div>
		<!-- <a href="home.php"><input type="button"  class="myButton" name="" value="BACK / HOME"></a> -->
		<a href="login.php" class="myButton">LOGIN</a>
		</div>

	</center>




</body>
</html>
