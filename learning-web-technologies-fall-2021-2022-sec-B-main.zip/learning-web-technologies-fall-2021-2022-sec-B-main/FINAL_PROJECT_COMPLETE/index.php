<?php

	header('location: Student/views/login.php');

?>